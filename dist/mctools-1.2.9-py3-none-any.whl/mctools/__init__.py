"""
mctools

See its help for description.

"""

